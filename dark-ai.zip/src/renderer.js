// ------------------------------------------------------------------
// Конфигурация моделей. Замени id на любые другие с Hugging Face,
// главное чтобы они были доступны через Inference API/Providers.
// ------------------------------------------------------------------
const MODELS = {
  'DARK-0': {
    id: 'Qwen/Qwen2.5-Coder-7B-Instruct',
    system: `Ты DARK-0 — ассистент-программист на Java со свободным доступом к открытой папке проекта.
Отвечай только на последнее сообщение пользователя, кратко и по делу, без извинений и без упоминаний "предыдущих ответов", которых не было.

Ниже в контексте дано дерево ВСЕХ файлов проекта и содержимое лишь части из них (самых маленьких/верхнеуровневых). Если для ответа тебе нужен файл, которого нет в контексте — НЕ говори "у меня нет доступа" и НЕ отказывайся. Вместо этого запроси его одним тегом на отдельной строке:
<read>относительный/путь/к/файлу.java</read>
Можно запросить сразу несколько файлов несколькими тегами. Тебе покажут их содержимое, и ты сможешь ответить на основе него.

Если нужно ИЗМЕНИТЬ файл — выведи его новое полное содержимое так:
<write path="относительный/путь/к/файлу.java">
...полный новый текст файла...
</write>
Файл будет реально перезаписан на диске, поэтому пиши туда весь файл целиком, а не фрагмент.

Обычный текстовый код для примера/объяснения (без записи на диск) давай как раньше — в блоках \`\`\`java.`
  },
  'DARK-1': {
    id: 'meta-llama/Llama-3.1-8B-Instruct',
    system: 'Ты DARK-1 — дружелюбный ассистент для общения на любые темы. Отвечай тепло и по-русски, если пользователь пишет по-русски.'
  },
  'DARK-2': {
    id: 'meta-llama/Llama-3.1-8B-Instruct',
    system: 'Ты DARK-2 — ассистент с доступом к результатам веб-поиска, приложенным ниже в контексте. Отвечай на основе них, указывай на неопределённость, если результатов недостаточно.'
  }
};

let state = {
  hfToken: '',
  chats: JSON.parse(localStorage.getItem('dark_chats') || '[]'),
  activeChatId: null,
  attachments: [],
  project: null // { root, name, tree, fileCount, contents }
};

const $ = (id) => document.getElementById(id);

function saveChats() {
  localStorage.setItem('dark_chats', JSON.stringify(state.chats));
}

function newChat() {
  const chat = { id: Date.now().toString(), title: 'Новый чат', messages: [] };
  state.chats.unshift(chat);
  state.activeChatId = chat.id;
  saveChats();
  renderChatList();
  renderMessages();
}

function getActiveChat() {
  return state.chats.find((c) => c.id === state.activeChatId);
}

function renderChatList() {
  const list = $('chatList');
  list.innerHTML = '';
  state.chats.forEach((chat) => {
    const div = document.createElement('div');
    div.className = 'chat-item' + (chat.id === state.activeChatId ? ' active' : '');
    div.textContent = chat.title;
    div.onclick = () => {
      state.activeChatId = chat.id;
      renderChatList();
      renderMessages();
    };
    list.appendChild(div);
  });
}

function renderMessages() {
  const box = $('messages');
  box.innerHTML = '';
  const chat = getActiveChat();
  if (!chat) return;
  chat.messages.forEach((m) => {
    const div = document.createElement('div');
    div.className = 'msg ' + m.role;
    div.textContent = m.content;
    box.appendChild(div);
  });
  box.scrollTop = box.scrollHeight;
}

function showTyping() {
  const box = $('messages');
  const div = document.createElement('div');
  div.className = 'typing';
  div.id = 'typingIndicator';

  const glyph = document.createElement('span');
  glyph.className = 'orb-glyph';
  const lattice = document.createElement('span');
  lattice.className = 'orb-lattice';

  // 3x3 решётка точек, круговая волна из центра — та же логика,
  // что в S1-варианте Orb (см. cellDelay), но на чистом CSS/JS.
  const N = 3, PITCH = 6, MID = (N - 1) / 2;
  for (let y = 0; y < N; y++) {
    for (let x = 0; x < N; x++) {
      const dx = x - MID, dy = y - MID;
      const delay = Math.hypot(dx, dy) * 700 - (dx === 0 && dy === 0 ? 180 : 0);
      const cell = document.createElement('span');
      cell.className = 'orb-cell';
      cell.style.left = x * PITCH + 'px';
      cell.style.top = y * PITCH + 'px';
      cell.style.animationDelay = delay + 'ms';
      lattice.appendChild(cell);
    }
  }
  glyph.appendChild(lattice);

  const label = document.createElement('span');
  label.className = 'typing-label';
  label.textContent = 'Думаю…';

  div.appendChild(glyph);
  div.appendChild(label);
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function hideTyping() {
  const el = $('typingIndicator');
  if (el) el.remove();
}

function addMessage(role, content) {
  const chat = getActiveChat();
  chat.messages.push({ role, content });
  if (chat.messages.length === 1) {
    chat.title = content.slice(0, 28) || 'Новый чат';
  }
  saveChats();
  renderChatList();
  renderMessages();
}

// ------------------------------------------------------------------
// Вложения (иконка ＋)
// ------------------------------------------------------------------
$('attachBtn').onclick = async () => {
  const files = await window.darkAPI.pickAttachments();
  state.attachments = state.attachments.concat(files.filter((f) => f.content !== null));
  renderAttachments();
};

function renderAttachments() {
  const box = $('attachmentsPreview');
  box.innerHTML = '';
  state.attachments.forEach((f, idx) => {
    const chip = document.createElement('div');
    chip.className = 'attachment-chip';
    chip.textContent = '📎 ' + f.name + '  ✕';
    chip.onclick = () => {
      state.attachments.splice(idx, 1);
      renderAttachments();
    };
    box.appendChild(chip);
  });
}

// ------------------------------------------------------------------
// Папка проекта (иконка папки) — ИИ "видит" её содержимое,
// проводник больше не открывается.
// ------------------------------------------------------------------
$('folderBtn').onclick = async () => {
  let snapshot = await window.darkAPI.getProjectSnapshot();
  if (!snapshot) {
    const folder = await window.darkAPI.pickFolder();
    if (!folder) return;
    snapshot = await window.darkAPI.getProjectSnapshot();
  } else {
    // папка уже подключена — повторный клик предлагает сменить её
    const folder = await window.darkAPI.pickFolder();
    if (folder) snapshot = await window.darkAPI.getProjectSnapshot();
  }
  applyProjectSnapshot(snapshot, true);
};

$('projectRefreshBtn').onclick = async (e) => {
  e.stopPropagation();
  const snapshot = await window.darkAPI.getProjectSnapshot();
  applyProjectSnapshot(snapshot, true);
};

$('projectClearBtn').onclick = async (e) => {
  e.stopPropagation();
  await window.darkAPI.clearFolder();
  applyProjectSnapshot(null, true);
};

function applyProjectSnapshot(snapshot, announce) {
  state.project = snapshot;
  const status = $('projectStatus');
  const text = $('projectStatusText');
  const btn = $('folderBtn');
  if (snapshot) {
    status.classList.remove('hidden');
    text.textContent = `${snapshot.name} — ${snapshot.fileCount} файл(ов) подключено`;
    btn.classList.add('active');
    if (announce && getActiveChat()) addMessage('system', `📁 Папка проекта «${snapshot.name}» подключена (${snapshot.fileCount} файлов). DARK-0 будет видеть её содержимое.`);
  } else {
    status.classList.add('hidden');
    btn.classList.remove('active');
    if (announce && getActiveChat()) addMessage('system', '📁 Папка проекта отключена.');
  }
}

// ------------------------------------------------------------------
// Настройки / токен HF
// ------------------------------------------------------------------
$('settingsBtn').onclick = () => $('settingsModal').classList.remove('hidden');
$('closeSettingsBtn').onclick = () => $('settingsModal').classList.add('hidden');
$('saveSettingsBtn').onclick = async () => {
  const token = $('hfTokenInput').value.trim();
  await window.darkAPI.setToken(token);
  state.hfToken = token;
  $('settingsModal').classList.add('hidden');
};

async function loadSettings() {
  const s = await window.darkAPI.getSettings();
  state.hfToken = s.hfToken;
  $('hfTokenInput').value = s.hfToken;
}

// ------------------------------------------------------------------
// Отправка сообщения в Hugging Face Inference API
// (используется OpenAI-совместимый роутер router.huggingface.co)
// ------------------------------------------------------------------
async function callModel(modelKey, chatHistory) {
  const cfg = MODELS[modelKey];
  if (!state.hfToken) {
    return 'Сначала укажи Hugging Face токен в Настройках (значок ⚙ в левом нижнем углу).';
  }

  let extraContext = '';
  if (modelKey === 'DARK-2') {
    extraContext = await webSearchContext(chatHistory[chatHistory.length - 1].content);
  }
  if (modelKey === 'DARK-0' && state.attachments.length) {
    extraContext += '\n\nПриложенные файлы:\n' +
      state.attachments.map((f) => `--- ${f.name} ---\n${f.content}`).join('\n\n');
  }
  if (modelKey === 'DARK-0' && state.project) {
    extraContext += `\n\n[СПРАВОЧНЫЙ КОНТЕКСТ — папка проекта "${state.project.name}", НЕ является вопросом пользователя]\n` +
      'Полное дерево файлов (для поиска нужного пути под <read>):\n' + state.project.tree.join('\n') +
      '\n\nСодержимое некоторых файлов уже загружено заранее:\n' +
      state.project.contents.map((f) => `--- ${f.path} ---\n${f.content}`).join('\n\n') +
      '\n[КОНЕЦ КОНТЕКСТА]';
  }

  const messages = [
    { role: 'system', content: cfg.system + (extraContext ? '\n\nКонтекст:\n' + extraContext : '') },
    ...chatHistory.map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content }))
  ];

  // DARK-0 с подключённой папкой — агентный цикл: модель может
  // запросить дополнительные файлы (<read>) или переписать файл (<write>)
  if (modelKey === 'DARK-0' && state.project) {
    return runAgentLoop(cfg, messages);
  }

  const reply = await askModel(cfg, messages);
  return typeof reply === 'string' ? reply : reply.error;
}

async function askModel(cfg, messages) {
  try {
    const res = await fetch('https://router.huggingface.co/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${state.hfToken}`
      },
      body: JSON.stringify({
        model: cfg.id,
        messages,
        max_tokens: 1200,
        temperature: 0.5
      })
    });

    if (!res.ok) {
      const errText = await res.text();
      return `Ошибка API (${res.status}): ${errText.slice(0, 300)}`;
    }

    const data = await res.json();
    return data.choices?.[0]?.message?.content?.trim() || 'Пустой ответ модели.';
  } catch (e) {
    return 'Не удалось связаться с Hugging Face: ' + e.message;
  }
}

// ------------------------------------------------------------------
// Агентный цикл для DARK-0: модель может сама запросить содержимое
// файла (<read>путь</read>) или переписать файл (<write path="...">).
// ------------------------------------------------------------------
const READ_TAG = /<read>\s*([^<\s][^<]*?)\s*<\/read>/g;
const WRITE_TAG = /<write\s+path="([^"]+)">([\s\S]*?)<\/write>/g;

async function runAgentLoop(cfg, initialMessages) {
  let messages = initialMessages;
  const writeSummaries = [];

  for (let step = 0; step < 4; step++) {
    const reply = await askModel(cfg, messages);
    if (typeof reply !== 'string') return reply;

    const reads = [...reply.matchAll(READ_TAG)].map((m) => m[1].trim());
    const writes = [...reply.matchAll(WRITE_TAG)];

    // Выполняем запись файлов, если модель их запросила
    for (const [, filePath, content] of writes) {
      const ok = await window.darkAPI.writeFile(filePath.trim(), content.trim());
      writeSummaries.push(ok
        ? `✅ Файл «${filePath.trim()}» обновлён.`
        : `⚠ Не удалось записать «${filePath.trim()}» — папка не подключена?`);
    }

    let cleanReply = reply.replace(WRITE_TAG, '').replace(READ_TAG, '').trim();

    // Если модель запросила файлы — читаем их и просим ответить ещё раз
    const uniqueReads = [...new Set(reads)].slice(0, 5);
    if (uniqueReads.length && step < 3) {
      const fileBlocks = [];
      for (const relPath of uniqueReads) {
        const content = await window.darkAPI.readFile(relPath);
        fileBlocks.push(content !== null
          ? `--- ${relPath} ---\n${content.slice(0, 12000)}`
          : `--- ${relPath} ---\n[файл не найден по этому пути, проверь дерево проекта]`);
      }
      messages = [
        ...messages,
        { role: 'assistant', content: reply },
        { role: 'user', content: 'Вот запрошенное содержимое файлов:\n\n' + fileBlocks.join('\n\n') + '\n\nТеперь ответь на исходный вопрос.' }
      ];
      continue; // ещё один круг, чтобы модель ответила уже с данными
    }

    // Финальный ответ (возможно, после записи файлов)
    const parts = [];
    if (cleanReply) parts.push(cleanReply);
    if (writeSummaries.length) parts.push(writeSummaries.join('\n'));
    return parts.join('\n\n') || 'Готово.';
  }

  return 'Не удалось получить окончательный ответ за разумное число шагов — попробуй переформулировать вопрос.';
}

// Простой веб-поиск для DARK-2 (лучший вариант — подключить платный
// поисковый API типа Serper/Tavily и подставить сюда ключ)
async function webSearchContext(query) {
  try {
    const res = await fetch('https://duckduckgo.com/html/?q=' + encodeURIComponent(query));
    const html = await res.text();
    const matches = [...html.matchAll(/class="result__snippet"[^>]*>([^<]+)</g)].slice(0, 5);
    if (!matches.length) return '';
    return matches.map((m, i) => `[${i + 1}] ${m[1]}`).join('\n');
  } catch (e) {
    return '';
  }
}

// ------------------------------------------------------------------
// Отправка формы
// ------------------------------------------------------------------
$('sendBtn').onclick = sendMessage;
$('promptInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

async function sendMessage() {
  const input = $('promptInput');
  const text = input.value.trim();
  if (!text) return;
  if (!getActiveChat()) newChat();

  addMessage('user', text);
  input.value = '';
  $('sendBtn').disabled = true;
  showTyping();

  const modelKey = $('modelSelect').value;
  const reply = await callModel(modelKey, getActiveChat().messages);
  hideTyping();
  addMessage('assistant', reply);

  state.attachments = [];
  renderAttachments();
  $('sendBtn').disabled = false;
}

$('newChatBtn').onclick = newChat;

// ------------------------------------------------------------------
// Инициализация
// ------------------------------------------------------------------
(async function init() {
  await loadSettings();
  if (state.chats.length === 0) newChat();
  else {
    state.activeChatId = state.chats[0].id;
  }
  renderChatList();
  renderMessages();

  const snapshot = await window.darkAPI.getProjectSnapshot();
  if (snapshot) applyProjectSnapshot(snapshot);
})();
