const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const Store = require('electron-store');

const store = new Store();
let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 720,
    minWidth: 760,
    minHeight: 480,
    backgroundColor: '#141414',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ---------- Настройки (API-ключ HF, выбранный код-проект) ----------
ipcMain.handle('settings:get', () => {
  return {
    hfToken: store.get('hfToken', ''),
    codeFolder: store.get('codeFolder', '')
  };
});

ipcMain.handle('settings:setToken', (_e, token) => {
  store.set('hfToken', token);
  return true;
});

// ---------- Выбор папки для DARK-0 (редактирование кода) ----------
ipcMain.handle('folder:pick', async () => {
  const res = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] });
  if (res.canceled || res.filePaths.length === 0) return null;
  const folder = res.filePaths[0];
  store.set('codeFolder', folder);
  return folder;
});

ipcMain.handle('folder:clear', () => {
  store.set('codeFolder', '');
  return true;
});

ipcMain.handle('folder:open', async () => {
  const folder = store.get('codeFolder', '');
  if (folder && fs.existsSync(folder)) {
    shell.openPath(folder);
    return true;
  }
  return false;
});

ipcMain.handle('folder:listFiles', () => {
  const folder = store.get('codeFolder', '');
  if (!folder || !fs.existsSync(folder)) return [];
  return fs.readdirSync(folder);
});

ipcMain.handle('folder:readFile', (_e, name) => {
  const folder = store.get('codeFolder', '');
  const p = path.join(folder, name);
  if (!fs.existsSync(p)) return null;
  return fs.readFileSync(p, 'utf-8');
});

ipcMain.handle('folder:writeFile', (_e, { name, content }) => {
  const folder = store.get('codeFolder', '');
  if (!folder) return false;
  const target = path.join(folder, name);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, content, 'utf-8');
  return true;
});

// ---------- "Взгляд" ИИ внутрь открытой папки проекта ----------
// Собирает дерево файлов + содержимое небольших текстовых файлов,
// чтобы передать это моделью как контекст (без открытия проводника).
const IGNORE_DIRS = new Set(['node_modules', '.git', 'dist', 'build', 'target', '.idea', '.vscode']);
const CODE_EXT = new Set(['.java', '.js', '.ts', '.json', '.md', '.txt', '.xml', '.gradle', '.properties', '.yml', '.yaml', '.py', '.html', '.css']);

function walk(dir, base, depth, maxDepth, out) {
  if (depth > maxDepth || out.files.length >= 60) return;
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (e) {
    return;
  }
  for (const entry of entries) {
    if (out.files.length >= 60) break;
    if (IGNORE_DIRS.has(entry.name) || entry.name.startsWith('.')) continue;
    const full = path.join(dir, entry.name);
    const rel = path.relative(base, full);
    if (entry.isDirectory()) {
      out.dirs.push(rel);
      walk(full, base, depth + 1, maxDepth, out);
    } else {
      out.files.push(rel);
    }
  }
}

ipcMain.handle('folder:getSnapshot', () => {
  const folder = store.get('codeFolder', '');
  if (!folder || !fs.existsSync(folder)) return null;

  const out = { dirs: [], files: [] };
  walk(folder, folder, 0, 5, out);

  const contents = [];
  let totalChars = 0;
  for (const rel of out.files) {
    if (totalChars > 40000 || contents.length >= 15) break;
    const ext = path.extname(rel).toLowerCase();
    if (!CODE_EXT.has(ext)) continue;
    try {
      const text = fs.readFileSync(path.join(folder, rel), 'utf-8').slice(0, 4000);
      contents.push({ path: rel, content: text });
      totalChars += text.length;
    } catch (e) {
      /* пропускаем нечитаемые файлы */
    }
  }

  return {
    root: folder,
    name: path.basename(folder),
    tree: [...out.dirs.map((d) => d + '/'), ...out.files],
    fileCount: out.files.length,
    contents
  };
});

// ---------- Прикрепление файлов к сообщению (иконка плюсика) ----------
ipcMain.handle('attach:pick', async () => {
  const res = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections']
  });
  if (res.canceled) return [];
  return res.filePaths.map((p) => ({
    path: p,
    name: path.basename(p),
    content: safeReadText(p)
  }));
});

function safeReadText(p) {
  try {
    const buf = fs.readFileSync(p);
    // ограничим размер вложения текстом ~50кб, чтобы не забивать контекст
    return buf.toString('utf-8').slice(0, 50000);
  } catch (e) {
    return null;
  }
}
