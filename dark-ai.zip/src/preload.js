const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('darkAPI', {
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setToken: (token) => ipcRenderer.invoke('settings:setToken', token),

  pickFolder: () => ipcRenderer.invoke('folder:pick'),
  clearFolder: () => ipcRenderer.invoke('folder:clear'),
  openFolder: () => ipcRenderer.invoke('folder:open'),
  listFiles: () => ipcRenderer.invoke('folder:listFiles'),
  readFile: (name) => ipcRenderer.invoke('folder:readFile', name),
  writeFile: (name, content) => ipcRenderer.invoke('folder:writeFile', { name, content }),
  getProjectSnapshot: () => ipcRenderer.invoke('folder:getSnapshot'),

  pickAttachments: () => ipcRenderer.invoke('attach:pick')
});
